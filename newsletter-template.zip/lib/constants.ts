export const TABLES = {
  EMAIL_LIST: "email-list",
};

export const socialLinks = {
  instagram: "https://www.instagram.com/joyco.studio",
  x: "https://x.com/joyco_studio",
  github: "https://github.com/joyco-studio",
};
